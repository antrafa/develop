public class TestaCalculadora {
	public static void main(String[] args) {
		Calculadora calc = new Calculadora();
		int r1 = calc.soma(3, 4);
		int r2 = calc.soma(3, 4, 5);

		double r3 = calc.soma(3f, 4f);

		short s1 = 2;
		short s2 = 3;

		int r4 = calc.soma(s1, s2);

		calc.soma(2, 3l);
		calc.soma(3l, 3);

		calc.soma(3, 3);
	}
}