public class CalculadoraErro {
	public long soma(long a, int b) {
		System.out.println("==>> soma(long num1, int num2)");
		return a + b;
	}
	public long soma(int a, long b) {
		System.out.println("==>> soma(int num1, long num2)");
		return a + b;
	}
}