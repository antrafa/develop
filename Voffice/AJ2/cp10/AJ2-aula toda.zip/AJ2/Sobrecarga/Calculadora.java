public class Calculadora {

	public int soma(int num1, int num2) {
		System.out.println("==>> soma(int num1, int num2)");
		return num1 + num2;
	}

	public int soma(int num1, int num2, int num3) {
		System.out.println("==>> soma(int num1, int num2, int num3)");
		return this.soma(num1, num2) + num3;
	}

	public double soma(double num1, double num2) {
		System.out.println("==>> soma(float num1, float num2)");
		return num1 + num2;
	}

	public long soma(int num1, long num2) {
		System.out.println("==>> soma(int num1, long num2)");
		return num1 + num2;
	}

	public long soma(long num1, int num2) {
		System.out.println("==>> soma(long num1, int num2)");
		return num1 + num2;
	}

	public long soma(long num1, long num2) {
		System.out.println("==>> soma(long num1, long num2)");
		return num1 + num2;
	}
}
