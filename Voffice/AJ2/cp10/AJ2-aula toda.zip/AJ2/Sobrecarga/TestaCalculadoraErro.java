public class TestaCalculadoraErro {
	public static void main(String[] args) {
		CalculadoraErro calc = new CalculadoraErro();
		calc.soma(1, 1l);
		calc.soma(1l, 1);
		calc.soma(1, 1)
	}
}