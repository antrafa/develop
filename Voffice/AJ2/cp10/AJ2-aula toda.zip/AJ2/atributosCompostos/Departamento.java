public class Departamento {
	private String nome;
	private Funcionario[] funcionarios = new Funcionario[0];

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getNome() {
		return this.nome;
	}

	public void setFuncionarios(Funcionario[] funcionarios) {
		this.funcionarios = funcionarios;
	}

	public Funcionario[] getFuncionarios() {
		return this.funcionarios;
	}

	public void addFuncionario(Funcionario funcionario) {
		Funcionario[] temp = new Funcionario[this.funcionarios.length + 1];

		for (int i = 0; i < this.funcionarios.length; i ++) {
			temp[i] = this.funcionarios[i];
		}
		temp[temp.length - 1] = funcionario;
		this.funcionarios = temp;
	}

	public void imprimeDados() {
		System.out.println("Nome: " + nome);
		for (Funcionario funcionario: funcionarios) {
			funcionario.imprimeDados();
		}
	}
}