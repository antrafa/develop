public class TestaDepartamento {
	public static void main(String[] args) {
		Funcionario funcionario1 = new Funcionario();
		funcionario1.inicializaFuncionario("Funcionario 01", "001");

		Funcionario funcionario2 = new Funcionario();
		funcionario2.inicializaFuncionario("Funcionario 02", "002");

		// Funcionario[] funcionarios = new Funcionario[]{funcionario1, funcionario2};

		Departamento departamento = new Departamento();
		departamento.setNome("TI");
		// departamento.setFuncionarios(funcionarios);
		departamento.addFuncionario(funcionario1);
		departamento.addFuncionario(funcionario2);

		departamento.imprimeDados();

		//adicionando mais um funcionario
		Funcionario funcionario3 = new Funcionario();
		funcionario3.inicializaFuncionario("Funcionario 03", "003");
		// funcionarios = departamento.getFuncionarios();

		// Funcionario[] temp = new Funcionario[funcionarios.length + 1];

		// for (int i = 0; i < funcionarios.length; i ++) {
		// 	temp[i] = funcionarios[i];
		// }
		// temp[temp.length - 1] = funcionario3;
		// departamento.setFuncionarios(temp);
		departamento.addFuncionario(funcionario3);

		departamento.imprimeDados();
	}
}