class Conta {
	double saldo;

	void deposito(double valor) {
		System.out.println("valor (recebido) = " + valor);
		saldo += valor;
		valor = saldo;
		System.out.println("valor (final) = " + valor);
	}
}