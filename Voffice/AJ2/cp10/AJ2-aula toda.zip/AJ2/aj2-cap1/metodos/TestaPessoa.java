class TestaPessoa {
	public static void main(String[] args) {
		Pessoa p = new Pessoa();
		p.inicializaPessoa("Jose da Slva", 1979);

		System.out.printf("Nome: %s %n", p.nome);
		System.out.printf("idade: %s %n", p.obtemIdade(2017));

	}
}