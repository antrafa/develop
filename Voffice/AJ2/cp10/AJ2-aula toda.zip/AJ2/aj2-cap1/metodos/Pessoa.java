class Pessoa {
	String nome;
	int anoNascimento;

	void inicializaPessoa(String novoNome, int novoAnoNascimento) {
		nome = novoNome;
		anoNascimento = novoAnoNascimento;

	}

	int obtemIdade(int anoAtual) {
		System.out.println("Pessei no obtemIdade");
		return anoAtual - anoNascimento;
	}

}