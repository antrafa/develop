class TestaParametroReferencia {
	public static void main(String[] args) {
		Pessoa p = new Pessoa();
		p.nome = "Maria";
		System.out.println("p (antes de chamar o metodo)" + p.nome);
		alteraPessoa(p);
		System.out.println("p (depois de chamar o metodo)" + p.nome);
		
	}

	static void alteraPessoa(Pessoa pessoa) {
		System.out.println("pessoa (recebido pelo matodo)" + pessoa.nome);
		pessoa.nome = "Jose";
		System.out.println("pessoa (alterado pelo matodo)" + pessoa.nome);

		pessoa = new Pessoa();
		pessoa.nome = "Geraldo";
		System.out.println("pessoa (alterado pelo matodo)" + pessoa.nome);
	}
}