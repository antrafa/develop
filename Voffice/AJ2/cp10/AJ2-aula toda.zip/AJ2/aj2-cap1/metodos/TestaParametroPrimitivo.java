class TestaParametroPrimitivo {
	public static void main(String[] args) {
		double v = 200;
		Conta c = new Conta();
		c.saldo = 1000;
		System.out.println("v (antes de chamar o metodo) = " + v);
		c.deposito(v);
		System.out.println("v (depois de chamar o metodo) = " + v);
	}
}