class InstrucaoInatingivel {
	boolean teste() {
		int i = 2;
		return true;
		if (i > 0) {
			return true;
		} else if (i == 0) {
			return false;
		} else {
			int x = 10;
			return x == i;
		}
	}
}