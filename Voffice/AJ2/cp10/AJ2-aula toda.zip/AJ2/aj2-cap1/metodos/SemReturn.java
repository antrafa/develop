class SemReturn {
	boolean teste() {
		int i = 2;
		if (i > 0) {
			return true;
		}
	}
}