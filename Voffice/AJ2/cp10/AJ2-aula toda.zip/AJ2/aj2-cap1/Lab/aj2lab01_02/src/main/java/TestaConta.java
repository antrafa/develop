/*
 * Globalcode - "The Developers Company"
 * 
 * Academia do Java
 */
class TestaConta {

    public static void main(String[] args) {
        // Criacao da conta
        Conta conta = new Conta();
        // Inicializacao da conta
        conta.inicializaConta(20000, "1", "Jose da Silva", 1, 1);
        // Impressao dos dados da conta
        conta.imprimeDados();
        // Saque da conta
        conta.saque(300);
        // Impressao dos dados da conta
        conta.imprimeDados();
        // Deposito em conta
        conta.deposito(100000);
        // Impressao dos dados da conta
        conta.imprimeDados();
    }
}
