class Produto {
	String codigo;
	String nome;
	double preco;
	String fabricante;
}