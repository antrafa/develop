class TestaProduto {
	public static void main(String[] args) {
		Produto produto1 = new Produto();
		Produto produto2 = new Produto();

		produto1.codigo = "001";
		produto1.nome = "Fogao 4 Bocas";
		produto1.preco = 500.23;
		produto1.fabricante = "Bosh";

		// produto2.codigo = "002";
		produto2.nome = "Tv 29 polegadas";
		// produto2.preco = 1900.28;
		produto2.fabricante = "Panassonic";	

		System.out.println("Produto 1: ");
		System.out.println(" codigo: " + produto1.codigo);
		System.out.println(" nome: " + produto1.nome);
		System.out.println(" preco: " + produto1.preco);
		System.out.println(" fabricante: " + produto1.fabricante);

		System.out.println("");

		System.out.println("Produto 2: ");
		System.out.println(" codigo: " + produto2.codigo.charAt(0));
		System.out.println(" nome: " + produto2.nome);
		System.out.println(" preco: " + produto2.preco);
		System.out.println(" fabricante: " + produto2.fabricante);

	}
}