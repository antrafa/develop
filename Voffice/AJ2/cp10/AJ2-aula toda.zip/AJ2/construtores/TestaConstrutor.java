public class TestaConstrutor {
	public static void main(String[] args) {
		Pessoa p = new Pessoa("", "dsd");

		Pessoa p2 = new Pessoa("", "dsd");
	}
}