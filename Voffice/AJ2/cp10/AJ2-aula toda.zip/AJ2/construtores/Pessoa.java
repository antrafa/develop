public class Pessoa {
	private String nome;
	private String cpf;

	{
		System.out.println("bloco 02");
	}

	public Pessoa() {
		System.out.println("construtor sem parametro");
	}

	public Pessoa(String nome) {
		this();
		System.out.println("construtor com um parametro");
		this.nome = nome;
	}

	public Pessoa(String nome, String cpf) {
		this(nome);
		System.out.println("construtor com dois parametro");
		this.cpf = cpf;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getNome() {
		return this.nome;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getCpf() {
		return cpf;
	}

	{
		System.out.println("bloco 01");
	}
}