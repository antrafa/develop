public class Estudante {
	private Curso[] cursos;
	private Endereco endereco;

	public Curso[] getCursos() {
		return cursos
	}
	public void setCursos(Curso[] cursos) {
		if (cursos == null || cursos.lenght == 0) {
			return;
		}
		this.cursos = cursos;
	}

	public Endereco getEndereco() {
		return endereco;
	}
	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}
}