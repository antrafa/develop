public class Endereco {
	
}