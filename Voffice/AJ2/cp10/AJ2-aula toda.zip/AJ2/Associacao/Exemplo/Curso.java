public Class Curso {
	private Estudante[] estudantesInscritos;

	public Estudante[] getEstudantesInscritos() {
		return estudantesInscritos;
	}

	public void setEstudantesInscritos(Estudante[] estudantesInscritos) {
		this.estudantesInscritos = estudantesInscritos;
	}

}