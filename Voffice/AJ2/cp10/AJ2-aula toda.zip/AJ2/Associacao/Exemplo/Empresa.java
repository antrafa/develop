public class Empresa {
	private Departamento[] departamentos;

	public Departamento[] getDepartamentos() {
		return departamentos;
	}

	public void setDepartamento(Departamento[] departamentos) {
		this.departamentos = departamentos;
	}
}