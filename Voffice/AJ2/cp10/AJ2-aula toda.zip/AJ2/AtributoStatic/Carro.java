public class Carro {
	{ 
		System.out.println("bloco instancia 01");
	}
	private String marca;
	private int velocidade;
	private static int velocidadeMaxima = 60;

	static { 
		System.out.println("bloco static 01");
	}

	public static int getVelocidadeMaxima() {
		return velocidadeMaxima;
	}

	public static void setVelocidadeMaxima(int novaVelocidadeMaxima) {
		velocidadeMaxima = novaVelocidadeMaxima;
	}

	public String getMarca() {
		return marca;
	}

	public Carro(String marca, int velocidade) {
		this.marca = marca;
		this.velocidade = velocidade;
	}

	public boolean ultrapassouLimite() {
		return this.velocidade > Carro.velocidadeMaxima;
	}
}