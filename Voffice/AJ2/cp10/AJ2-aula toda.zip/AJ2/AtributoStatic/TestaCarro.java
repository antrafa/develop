public class TestaCarro {

	static { 
		System.out.println("bloco static TestaCarro");
	}

	public static void main(String[] args) {
		Carro c1 = new Carro("volks", 40);
		Carro c2 = new Carro("Fiat", 50);

		System.out.println("Valocidade Maxima " + Carro.getVelocidadeMaxima());
		System.out.println("Carro " + c1.getMarca() + " ultrapassou? = " + c1.ultrapassouLimite());
		System.out.println("Carro " + c2.getMarca() + " ultrapassou? = " + c2.ultrapassouLimite());

		c1.setVelocidadeMaxima(40);

		System.out.println("Valocidade Maxima " + Carro.getVelocidadeMaxima());
		System.out.println("Carro " + c1.getMarca() + " ultrapassou? = " + c1.ultrapassouLimite());
		System.out.println("Carro " + c2.getMarca() + " ultrapassou? = " + c2.ultrapassouLimite());

	}
}