public class TestaHeranca {
	public static void main(String[] args) {

		Funcionario f = new Funcionario("Joaquim", "3333333");

		System.out.println(f);
	}
}