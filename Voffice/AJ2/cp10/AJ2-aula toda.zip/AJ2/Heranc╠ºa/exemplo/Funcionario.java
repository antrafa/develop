public class Funcionario extends Pessoa {
 	private String carteiraTrabalho;

 	{
 		System.out.println("bloco inicializacao Funcionario");
 	}

 	public Funcionario(String nome, String carteiraTrabalho) {
 		super(nome);
		System.out.println("construtor Funcionario");
 		this.carteiraTrabalho = carteiraTrabalho;
 	}

 	public String getCarteiraTrabalho() {
 		return carteiraTrabalho;
 	}

 	public void setCarteiraTrabalho(String carteiraTrabalho) {
 		this.carteiraTrabalho = carteiraTrabalho;
 	}

 	public String toString() {
 		return super.toString() + " | carteiraTrabalho = " + carteiraTrabalho;
 	}

}