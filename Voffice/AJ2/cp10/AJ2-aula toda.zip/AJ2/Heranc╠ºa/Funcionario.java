public class Funcionario extends Pessoa {
 	private String carteiraTrabalho;

 	public Funcionario(String nome, String carteiraTrabalho) {
 		super(nome);
 		this.carteiraTrabalho = carteiraTrabalho;
 	}

 	public String getCarteiraTrabalho() {
 		return carteiraTrabalho;
 	}

 	public void setCarteiraTrabalho(String carteiraTrabalho) {
 		this.carteiraTrabalho = carteiraTrabalho;
 	}

 	public String toString() {
 		return super.toString() + " | carteiraTrabalho = " + carteiraTrabalho;
 	}

}