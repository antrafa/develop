public class Cliente extends Pessoa {
	private TipoPessoa tipo;

	public Cliente(String nome, TipoPessoa tipo) {
		super(nome);
		this.tipo = tipo;
	}

	public TipoPessoa getTipoPessoa() {
		return tipo;
	}

	public void setTipoPessoa(TipoPessoa tipo) {
		this.tipo = tipo;
	}

	public void imprimeDados() {
		super.imprimeDados();
		System.out.println("Tipo: " + (tipo == TipoPessoa.PESSOA_FISICA ? " Pessoa Fisica " : " Pessoa Juridica "));
	}
}