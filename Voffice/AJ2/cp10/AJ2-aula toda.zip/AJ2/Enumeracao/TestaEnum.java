public class TestaEnum {
	public static void main(String[] args) {
		Cliente cliente = new Cliente("Jose", TipoPessoa.PESSOA_JURIDICA);
		cliente.imprimeDados();

		System.out.println("==>> " + TipoPessoa.PESSOA_JURIDICA.ordinal());
		System.out.println("==>> " + TipoPessoa.PESSOA_JURIDICA.name());

		for (TipoPessoa tipo : TipoPessoa.values()) {
			System.out.println(tipo.ordinal() + " " + tipo);
		}
	}
}