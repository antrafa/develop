/*
 * Globalcode - "The Developers Company"
 * 
 * Academia do Java 
 * 1) Construa um objeto da classe Conta com cada construtor e chame o metodo imprimeDados 
 * 2) Construa um objeto da classe Cliente e chame o metodo imprimeDados
 * 
 */
public class TestaConstrutores {

    public static void main(String[] args) {
    	Conta conta1 = new Conta("123", "Maria", "11", 1);
    	conta1.imprimeDados();
    	Conta conta2 = new Conta(3000, "333", "Jose", "22", 2);
    	conta2.imprimeDados();

    	Cliente cliente = new Cliente("Joao", "232323");
    	cliente.imprimeDados();
    }
}
