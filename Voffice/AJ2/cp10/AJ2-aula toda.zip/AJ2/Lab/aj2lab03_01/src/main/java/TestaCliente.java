/*
 * Globalcode - "The Developers Company"
 * 
 * Academia do Java
 */
/**
 * @author Globalcode
 * 
 */
public class TestaCliente {

    public static void main(String[] args) {
        // Criacao do cliente
         Cliente cliente = new Cliente();
        // Inicializacao do cliente usando o metodo inicializaCliente
         cliente.inicializaCliente("Jose da Silva", "111.111.111-11");
        // Impressao dos dados do cliente
         cliente.imprimeDados();
    }
}
