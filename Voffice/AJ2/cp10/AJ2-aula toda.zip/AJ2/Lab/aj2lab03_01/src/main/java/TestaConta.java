/*
 * Globalcode - "The Developers Company"
 * 
 * Academia do Java
 */
public class TestaConta {

    public static void main(String[] args) {
        // Criar um objeto do tipo Conta
        Conta conta = new Conta();
        // Usar o metodo inicializaConta para fazer a inicializacao do objeto criado
        conta.inicializaConta(200, "123", "Josea da Silva", 1, 1);
        // executar um deposito
        conta.deposito(1000.20);
        // Imprimir o saldo apos o deposito
        conta.imprimeDados();
        // executar um saque cujo valor seja menor que o saldo
        conta.saque(200.33);
        // Imprimir o saldo apos o deposito
        conta.imprimeDados();
        // executar uma retirada cujo valor seja maior que o saldo
        conta.saque(20000);
        // Imprimir o saldo apos o deposito
        conta.imprimeDados();
    }
}
