 public class Pessoa {
	private String nome;
	private String cpf;
	private int anoNascimento;

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getNome() {
		return this.nome;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getCpf() {
		return cpf;
	}

	public void setAnoNascimento(int anoNascimento) {
		if (!isAnoValido(anoNascimento)) {
			System.out.println("Ano nascimento deve ser positivo");
			return;
		}
		this.anoNascimento = anoNascimento;
	}

	boolean isAnoValido(int ano) {
		return ano > 0;
	}

	public int getAnoNascimento() {
		return anoNascimento;
	}

	public void inicializaPessoa(String nome, String cpf, int anoNascimento) {
		setAnoNascimento(anoNascimento);
		setNome(nome);
		setCpf(cpf);
	}

	public void imprimeDados() {
		System.out.println("Nome      : " + nome);
		System.out.println("CPF       : " + cpf);
		System.out.println("Nascimento: " + anoNascimento);
		System.out.println("this.     : " + this);
	}

	public int calculaIdade(int anoAtual) {
		return anoAtual - anoNascimento;
	}
}