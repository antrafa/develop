class TestaPessoa {
	public static void main(String[] args) {
		Pessoa p = new Pessoa();
		p.inicializaPessoa("Maria", "1111111111", -1979);
		p.setAnoNascimento(1980);
		p.imprimeDados();
		System.out.println("Idade: " + p.calculaIdade(2017));

		System.out.println("Pessoa: " + p);

		Pessoa p2 = new Pessoa();
		p2.imprimeDados();
		System.out.println("Pessoa: " + p2);
	}
}