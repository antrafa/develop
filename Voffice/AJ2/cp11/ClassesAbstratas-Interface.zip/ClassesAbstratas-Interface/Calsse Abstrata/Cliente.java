public class Cliente extends PessoaFisica {
	public void teste() {
		System.out.println("Teste em Clietne");
	}

	public void batata() {
		System.out.println("Batata em Clietne");
	}
}