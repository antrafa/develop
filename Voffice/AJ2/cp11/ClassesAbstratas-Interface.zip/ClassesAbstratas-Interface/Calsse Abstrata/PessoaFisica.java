public abstract class PessoaFisica extends Pessoa {
	public abstract void batata();
} 