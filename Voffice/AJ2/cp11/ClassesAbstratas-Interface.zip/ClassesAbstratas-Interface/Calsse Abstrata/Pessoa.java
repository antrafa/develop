public abstract class Pessoa {
	private String nome;

	public abstract void teste();

	public void executar() {
		System.out.println("executar em Pessoa");
		teste();
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	} 
}