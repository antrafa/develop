public class TesteAbstract {
	public static void main(String[] args) {
		//nao posso instanciar esta linha gera erro de compilacao
		//Pessoa p = new Pessoa(); 

		Cliente pf = new Cliente();
		pf.setNome("Maria");
		System.out.println("Nome: " + pf.getNome());
		pf.batata();
		pf.executar();
	}
}