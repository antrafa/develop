public interface Transportavel {
	double getPeso();
}