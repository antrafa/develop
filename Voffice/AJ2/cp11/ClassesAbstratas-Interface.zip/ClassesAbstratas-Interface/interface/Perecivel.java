public interface Perecivel {
	int diasArmazenamento();
}