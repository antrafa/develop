public class Alimento implements Transportavel, Perecivel {
	public double getPeso() {
		return 100;
	}

	public int diasArmazenamento() {
		return 10;
	}
}