public interface Remuneravel {
	public double calcularPagamento();
}