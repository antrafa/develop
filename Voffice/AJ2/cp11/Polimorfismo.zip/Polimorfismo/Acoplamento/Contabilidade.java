public class Contabilidade {
	public void calcularFolhaPorFuncionario(Funcionario...funcionarios) {
		for (Funcionario funcionario : funcionarios) {
			System.out.println(funcionario.getNome() + " - Remuneração = " + funcionario.calcularPagamento());
		}
	}

	public void calcularTotalfolha(Remuneravel...remuneraveis) {
		double soma = 0;
		for(Remuneravel remuneravel : remuneraveis) {
			soma += remuneravel.calcularPagamento();
		}

		System.out.println("Total Folha: " + soma);
	}
}