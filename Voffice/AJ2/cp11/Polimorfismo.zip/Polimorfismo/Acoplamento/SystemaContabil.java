public class SystemaContabil {
	public static void main(String[] args) {
		FuncionarioCLT clt1 = new FuncionarioCLT("Maria", 10000);
		FuncionarioCLT clt2 = new FuncionarioCLT("Jorge", 2000);
		FuncionarioPJ pj1 = new FuncionarioPJ("Joaquim", 30);
		pj1.setQuantidadeHoras(160);
		FuncionarioPJ pj2 = new FuncionarioPJ("Ana", 100);
		pj2.setQuantidadeHoras(80);

		Estagiario es = new Estagiario("Batata", 0.02, 0.01);
		es.apurarProdutividade(2, 22, 3);

		Contabilidade contabilidade = new Contabilidade();

		contabilidade.calcularFolhaPorFuncionario(clt1, pj1, clt2, pj2, es);

		contabilidade.calcularTotalfolha(clt1, pj1, clt2, pj2, es);

	}
}