public class FuncionarioPJ extends Funcionario {
	private double valorHora;
	private int quantidadeHoras;

	public FuncionarioPJ(String nome, double valorHora) {
		super(nome);
		this.valorHora = valorHora;
	}

	public void setQuantidadeHoras(int quantidadeHoras) {
		this.quantidadeHoras = quantidadeHoras;
	}

	public double calcularPagamento() {
		return valorHora * quantidadeHoras;
	}
}