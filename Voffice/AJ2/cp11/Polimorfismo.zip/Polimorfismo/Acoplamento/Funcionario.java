public abstract class Funcionario extends Pessoa implements Remuneravel {
	public Funcionario(String nome) {
		super(nome);
	}
}