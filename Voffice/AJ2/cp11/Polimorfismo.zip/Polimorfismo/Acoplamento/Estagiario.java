public class Estagiario extends Funcionario {
	private double valorPorPaozinho;
	private double valorPorLoteria;
	private int quantidadePaozinho;
	private int quantidadeLoteria;
	private int quantidadeReclamacao;

	public Estagiario(String nome, double valorPorPaozinho, double valorPorLoteria) {
		super(nome);
		this.valorPorPaozinho = valorPorPaozinho;
		this.valorPorLoteria = valorPorLoteria;
	}

	public void apurarProdutividade(int quantidadeLoteria, int quantidadePaozinho, int quantidadeReclamacao) {
		this.quantidadeLoteria = quantidadeLoteria;
		this.quantidadePaozinho = quantidadePaozinho;
		this.quantidadeReclamacao = quantidadeReclamacao;
	}

	public double calcularPagamento() {
		int div = 1 + quantidadeReclamacao;
		return ((valorPorPaozinho * quantidadePaozinho) + (valorPorLoteria * quantidadeLoteria)) / div;
	}
}