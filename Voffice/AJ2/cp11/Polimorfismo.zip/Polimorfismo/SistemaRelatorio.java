public class SistemaRelatorio {
	public static void main(String[] args) {
		Funcionario f = new Funcionario("Jose", 100);
		Cliente c = new Cliente("Maria", "3333333");
		Pessoa p = new Pessoa("Marcela");
		Pessoa pf = new Funcionario("Joao", 30);

		Relatorios rel = new Relatorios();

		rel.relatorioPessoas(f, c, p, pf);
	}
}