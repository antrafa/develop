public class Relatorios {
	public void imprimeDadosPessoais(Pessoa p) {
		System.out.println("Nome: " + p.getNome());
	}

	public void relatorioPessoas(Pessoa...pessoas) {
		for (Pessoa pessoa : pessoas) {
			imprimeDadosPessoais(pessoa);
		}
	}
}
