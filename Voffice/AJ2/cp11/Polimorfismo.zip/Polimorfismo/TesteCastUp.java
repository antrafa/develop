public class TesteCastUp {
	public static void main(String[] args) {
		Cliente c = new Cliente("1111111");
		c.nome = "Maria";
		c.endereco = "Rua Beiramar";

		System.out.println("Cliente: " + c);
		System.out.println("Cliente nome: " + c.nome);
		System.out.println("Cliente endereco: " + c.endereco);
		System.out.println("Cliente cpf: " + c.cpf);

		Pessoa p = c;
		System.out.println("Pessoa: " + p);
		System.out.println("Pessoa nome: " + p.nome);
		System.out.println("Pessoa endereco: " + p.endereco);
		//System.out.println("Pessoa cpf: " + p.cpf);

		Cliente c2 = (Cliente)p;
		System.out.println("Cliente 2: " + c2);
		System.out.println("Cliente 2 nome: " + c2.nome);
		System.out.println("Cliente 2 endereco: " + c2.endereco);
		System.out.println("Cliente 2 cpf: " + c2.cpf);

		Pessoa p1 = new Funcionario();
		p1.nome = "Maria2";
		p1.endereco = "Rua Beiramar 2";

		//Cliente c3 = (Cliente) p1;

		Pessoa p3 = new Cliente("11111sssd");
		Cliente c4 = (Cliente)p3;
		System.out.println("Cliente 4: " + c4);
		System.out.println("Cliente 4 nome: " + c4.nome);
		System.out.println("Cliente 4 endereco: " + c4.endereco);
		System.out.println("Cliente 4 cpf: " + c4.cpf);
	}
}