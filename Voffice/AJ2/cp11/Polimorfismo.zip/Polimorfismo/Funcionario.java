public class Funcionario extends Pessoa {
	public double salario;

	public Funcionario(String nome, double salario) {
		super(nome);
		this.salario = salario;
	}

	public String getNome() {
		return "Funcionario(a): " + super.getNome();
	}

	public double getSalario() {
		return salario;
	}	

	public void setSalario(double salario) {
		this.salario = salario;
	}
}